import mysql.connector
from config.config import Config
import logging

logger = logging.getLogger(__name__)

def get_db_connection():
    try:
        connection = mysql.connector.connect(
            host=Config.MYSQL_HOST,
            user=Config.MYSQL_USER,
            password=Config.MYSQL_PASSWORD,
            database=Config.MYSQL_DATABASE
        )
        if connection.is_connected():
            logger.info("Successfully connected to the database.")
            return connection
    except mysql.connector.Error as err:
        logger.error(f"Error: {err}")
    return None

def close_db_connection(connection):
    try:
        if connection.is_connected():
            connection.close()
            logger.info("Database connection closed.")
    except mysql.connector.Error as err:
        logger.error(f"Error closing the connection: {err}")
