# WhatsApp Sipariş ve Ödeme Sistemi

Bu proje, WhatsApp üzerinden sipariş almayı ve ödeme işlemlerini yönetmeyi amaçlayan bir müşteri destek sistemidir. OpenAI'nin ChatGPT API'si, UltraMsg WhatsApp API'si, WooCommerce REST API ve çeşitli görüntü işleme kütüphaneleri kullanılarak geliştirilmiştir.

## Gereksinimler

- Python 3.x
- OpenAI API Anahtarı
- UltraMsg API Anahtarı
- WooCommerce API Anahtarı
- MySQL Veritabanı

## Kurulum

1. Bu depoyu klonlayın:

   ```bash
   git clone https://github.com/yourusername/whatsapp-order-system.git
   cd whatsapp-order-system
