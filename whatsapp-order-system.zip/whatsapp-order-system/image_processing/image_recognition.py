import cv2
import pytesseract
from PIL import Image
import numpy as np
import torch
import torch.nn as nn
from torchvision import transforms
from ecommerce.woocommerce_api import get_product
from database.db_connection import get_db_connection, close_db_connection
import logging

logger = logging.getLogger(__name__)

# Modelinizi PyTorch ile yükleyin
class CustomModel(nn.Module):
    def __init__(self):
        super(CustomModel, self).__init__()
        # Model mimarinizi burada tanımlayın

    def forward(self, x):
        # İleri doğru geçiş işlemi
        return x

model = CustomModel()
model.load_state_dict(torch.load('path_to_your_model.pth'))
model.eval()

# Görüntü ön işleme işlemi
def preprocess_image(image):
    transform = transforms.Compose([
        transforms.ToPILImage(),
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    ])
    return transform(image)

# Ürün tanıma işlemi
def recognize_product(image_path):
    try:
        image = cv2.imread(image_path)
        if image is None:
            logger.error("Image not found.")
            return "Image not found"
        
        processed_image = preprocess_image(image)
        processed_image = processed_image.unsqueeze(0)  # Batch boyutunu ekleyin

        with torch.no_grad():
            predictions = model(processed_image)
            predicted_product_id = torch.argmax(predictions, dim=1).item()

        connection = get_db_connection()
        cursor = connection.cursor()
        cursor.execute("SELECT product_id FROM products WHERE id=%s", (predicted_product_id,))
        product = cursor.fetchone()
        close_db_connection(connection)

        if product:
            return product[0]
        return "Ürün bulunamadı"
    except Exception as e:
        logger.error(f"Error processing image: {e}")
        return "Image processing error"

# Görüntüden metin çıkarma işlemi
def extract_text_from_image(image_path):
    try:
        image = Image.open(image_path)
        text = pytesseract.image_to_string(image)
        logger.info("Text extracted from image successfully.")
        return text
    except Exception as e:
        logger.error(f"Error extracting text from image: {e}")
        return "Text extraction error"
