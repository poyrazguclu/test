import fitz  # PyMuPDF
import pytesseract
from PIL import Image
import re
import logging

logger = logging.getLogger(__name__)

def extract_text_from_pdf(pdf_path):
    try:
        text = ""
        with fitz.open(pdf_path) as pdf:
            for page in pdf:
                text += page.get_text()
        logger.info("Text extracted from PDF successfully.")
        return text
    except Exception as e:
        logger.error(f"Error extracting text from PDF: {e}")
        return "PDF extraction error"

def extract_text_from_html(html_path):
    try:
        with open(html_path, 'r', encoding='utf-8') as file:
            text = file.read()
        logger.info("Text extracted from HTML successfully.")
        return text
    except Exception as e:
        logger.error(f"Error extracting text from HTML: {e}")
        return "HTML extraction error"

def extract_text_from_image(image_path):
    try:
        image = Image.open(image_path)
        text = pytesseract.image_to_string(image)
        logger.info("Text extracted from image successfully.")
        return text
    except Exception as e:
        logger.error(f"Error extracting text from image: {e}")
        return "Image extraction error"

def verify_receipt(content, expected_name, expected_iban, expected_amount):
    try:
        name_match = re.search(expected_name, content, re.IGNORECASE)
        iban_match = re.search(expected_iban, content)
        amount_match = re.search(expected_amount, content)
        is_valid = bool(name_match and iban_match and amount_match)
        if is_valid:
            logger.info("Receipt verified successfully.")
        else:
            logger.warning("Receipt verification failed.")
        return is_valid
    except Exception as e:
        logger.error(f"Error verifying receipt: {e}")
        return False
