from woocommerce import API
from config.config import Config
import requests
import logging

logger = logging.getLogger(__name__)

wcapi = API(
    url="https://gamesmobile.fun",  # WooCommerce mağazanızın URL'si
    consumer_key=Config.WOOCOMMERCE_CONSUMER_KEY,
    consumer_secret=Config.WOOCOMMERCE_CONSUMER_SECRET,
    wp_api=True,
    version="wc/v3",
    timeout=15,
    verify_ssl=True,
    query_string_auth=True,
    user_agent="YourCustomUserAgent/1.0"
)

def get_product(product_id):
    try:
        response = wcapi.get(f"products/{product_id}")
        response.raise_for_status()
        logger.info(f"Product fetched successfully: {product_id}")
        return response.json()
    except requests.exceptions.RequestException as e:
        logger.error(f"Error fetching product: {e}")
        return None

def get_product_price(product_id):
    product = get_product(product_id)
    if product and 'price' in product:
        try:
            price = float(product['price'])
            logger.info(f"Product price fetched successfully: {price}")
            return price
        except (KeyError, TypeError, ValueError) as e:
            logger.error(f"Error parsing product price: {e}")
    else:
        logger.error("Product price not found.")
    return None

def get_product_from_link(product_link):
    try:
        response = wcapi.get("products", params={"search": product_link})
        response.raise_for_status()
        products = response.json()
        if products:
            logger.info(f"Product fetched successfully from link: {product_link}")
            return products[0]  # İlk ürünü döndürün
        else:
            logger.warning("No product found for the given link.")
            return None
    except requests.exceptions.RequestException as e:
        logger.error(f"Error fetching product from link: {e}")
        return None

def create_order(order_data):
    try:
        response = wcapi.post("orders", order_data)
        response.raise_for_status()
        logger.info("Order created successfully.")
        return response.json()
    except requests.exceptions.RequestException as e:
        logger.error(f"Error creating order: {e}")
        return None
