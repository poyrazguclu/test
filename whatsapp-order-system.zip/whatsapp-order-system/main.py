from flask import Flask, request, jsonify
from whatsapp.whatsapp_api import process_incoming_message, send_whatsapp_message, set_ultramsg_webhook
from config.config import Config
import logging
import requests

app = Flask(__name__)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@app.route('/webhook', methods=['POST'])
def webhook():
    try:
        data = request.json
        logger.info(f"Received webhook data: {data}")
        process_incoming_message(data)
        return jsonify({'status': 'success'}), 200
    except Exception as e:
        logger.error(f"Error processing webhook data: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500

def set_ultramsg_webhook():
    url = f"https://api.ultramsg.com/{Config.ULTRAMSG_API_TOKEN}/setWebhook"
    payload = {'webhook': 'https://yourdomain.com/webhook'}
    headers = {'Authorization': f'Bearer {Config.ULTRAMSG_API_TOKEN}'}

    response = requests.post(url, json=payload, headers=headers)
    if response.status_code == 200:
        logger.info("Webhook set successfully")
    else:
        logger.error("Failed to set webhook", response.json())

if __name__ == '__main__':
    set_ultramsg_webhook()
    app.run(port=5000)
