class Config:
    OPENAI_API_KEY = 'sk-proj-iKGPPSraxG2kDVmRokWwT3BlbkFJEdTkRRUxeaUaUu1bnOYS'
    ULTRAMSG_INSTANCE_ID = 'instance88210'  # UltraMsg instance ID
    ULTRAMSG_API_TOKEN = 'gvwd3285c6gx5rc4'  # UltraMsg API token
    WOOCOMMERCE_CONSUMER_KEY = 'ck_aef88699922cb3257476fe7115862b26c1e75013'
    WOOCOMMERCE_CONSUMER_SECRET = 'cs_94f893cd63175d785f82d377f5f4280ee26a6da0'
    MYSQL_HOST = 'localhost'
    MYSQL_USER = 'your_user'
    MYSQL_PASSWORD = 'your_password'
    MYSQL_DATABASE = 'your_database'
    JWT_SECRET_KEY = 'uemv6uarv2'
