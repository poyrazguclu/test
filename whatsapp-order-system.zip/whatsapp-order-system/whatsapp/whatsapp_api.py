import requests
from config.config import Config
import logging
from image_processing.image_recognition import recognize_product  # recognize_product işlevini içe aktarın
from ai.chatgpt_integration import get_chatgpt_response
from ecommerce.woocommerce_api import get_product_from_link

logger = logging.getLogger(__name__)

def send_whatsapp_message(phone, message):
    try:
        url = f'https://api.ultramsg.com/{Config.ULTRAMSG_INSTANCE_ID}/messages/chat'
        payload = {'to': phone, 'body': message}
        headers = {'content-type': 'application/json', 'Authorization': f'Bearer {Config.ULTRAMSG_API_TOKEN}'}
        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()
        logger.info(f"Message sent to {phone}: {message}")
        return response.json()
    except requests.exceptions.RequestException as e:
        logger.error(f"Error sending WhatsApp message: {e}")
        return None

def process_incoming_message(data):
    message_body = data.get('body', '')
    sender = data.get('from', '')

    if 'image' in data:
        product_info = recognize_product(data['image'])
        send_whatsapp_message(sender, f"Ürün Bilgisi: {product_info}")
    elif 'link' in data:
        product_info = get_product_from_link(data['link'])
        send_whatsapp_message(sender, f"Ürün Bilgisi: {product_info}")
    else:
        response = get_chatgpt_response(message_body, [])
        send_whatsapp_message(sender, response)

def set_ultramsg_webhook():
    url = f"https://api.ultramsg.com/{Config.ULTRAMSG_INSTANCE_ID}/setWebhook"
    payload = {'webhook': 'https://yourdomain.com/webhook'}
    headers = {'Authorization': f'Bearer {Config.ULTRAMSG_API_TOKEN}'}

    response = requests.post(url, json=payload, headers=headers)
    if response.status_code == 200:
        logger.info("Webhook set successfully")
    else:
        logger.error("Failed to set webhook", response.json())
